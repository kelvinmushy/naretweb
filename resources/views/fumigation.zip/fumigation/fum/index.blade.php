@extends('layouts.furm.master')
@section('top')
    <!-- DataTables -->
    <link rel="stylesheet" href="{{ asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') }}">

    <!-- daterange picker -->
    <link rel="stylesheet" href="{{ asset('assets/bower_components/bootstrap-daterangepicker/daterangepicker.css') }}">
    <!-- bootstrap datepicker -->
    <link rel="stylesheet" href="{{ asset('assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css') }}">
@endsection
@section('content')
    <div class="box">
        <div class="box-header">
            <h3 class="box-title"> Invoices</h3>
        </div>

        <div class="box-header">
            <button class='btn btn-primary' id='add_btn'>Create New</button>
        
        </div>
        <!-- /.box-header -->
        <div class="box-body">
        <div class="table-responsive">
              <table id="staffing-table" class="table table-striped">
                <thead>
                <tr>
                <th>Invoice Number</th>
                <th>Name</th>
                <th>Date:</th>
                <th>Sub Total</th>
                <th>VAT</th>
                <th>DisCount</th>
                     <th>Net Total</th>
                    <th>Amount Paid</th>
                    <th>Amount due</th>
                    <th>Payment status</th>
                    <th>Invoice Status</th>
                    <th>Start Date</th>
                    <th>Due Date</th>
                   <th></th>
                </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
        </div>
        <!-- /.box-body -->
        <div class="box-body">
      
      <table class="table table-striped" >
          <thead>
          <h3 class="text-info">Closed Invoices</h3>
          <tr>
          <th>Invoice Number</th>
                  <th>Name</th>
                  <th>Date:</th>
                  <th>Sub Total</th>
                  <th>VAT</th>
                  <th>DisCount</th>
                     <th>Net Total</th>
                    <th>Amount Paid</th>
                    <th>Amount due</th>
                    <th>Payment status</th>
                    <th>Invoice Status</th>
                    <th>Start Date</th>
                    <th>Due Date</th>
          </tr>
          </thead>
          @foreach($closed_invoice as $i)
              <tbody>
              <td>{{ $i->name}}</td>
              <td>{{ $i->invoice_number}}</td>
              <td>{{ $i->date_in}}</td>
              <td>{{ $i->sub_total}}</td>
              <td>{{ $i->vat}}</td>
              <td>{{ $i->discount}}</td>
              <td>{{ $i->net_total}}</td>
              <td>{{ $i->amount_paid}}</td>
              <td>{{ $i->amount_due}}</td>
              <td>{{ $i->payment_status}}</td>
              <td>{{ $i->invoice_status}}</td>
              <td>{{ $i->start_date}}</td>
              <td>{{ $i->due_date}}</td>
            
              <td>
                  <a href="" class="btn btn-sm btn-info"><i class="glyphicon glyphicon-eye-open"></i>View</a>
              </td>
              </tbody>
          @endforeach
     
      </table>
  </div>
    </div>
    <div class="box col-md-6">
    {{--<div class="box-header">--}}
    {{--<a onclick="addForm()" class="btn btn-primary" >New Invoice</a>--}}
    <!-- {{--<a href="" class="btn btn-danger">Export PDF</a>--}}
    {{--<a href="" class="btn btn-success">Export Excel</a>--}} -->
    {{--</div>--}}   
    </div>
    @include('fumigation.fum.form');
@endsection

@section('bot')
@include('fumigation.fum.pay');
    <!-- DataTables -->
    <script src=" {{ asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js') }} "></script>
    <script src="{{ asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') }} "></script>


    <!-- InputMask -->
    <script src="{{ asset('assets/plugins/input-mask/jquery.inputmask.js') }}"></script>
    <script src="{{ asset('assets/plugins/input-mask/jquery.inputmask.date.extensions.js') }}"></script>
    <script src="{{ asset('assets/plugins/input-mask/jquery.inputmask.extensions.js') }}"></script>
    <!-- date-range-picker -->
    <script src="{{ asset('assets/bower_components/moment/min/moment.min.js') }}"></script>
    <script src="{{ asset('assets/bower_components/bootstrap-daterangepicker/daterangepicker.js') }}"></script>
    <!-- bootstrap datepicker -->
    <script src="{{ asset('assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <!-- bootstrap color picker -->
    <script src="{{ asset('assets/bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js') }}"></script>
    <!-- bootstrap time picker -->
    <script src="{{ asset('assets/plugins/timepicker/bootstrap-timepicker.min.js') }}"></script>
    {{-- Validator --}}
    <script src="{{ asset('assets/validator/validator.min.js') }}"></script>

    {{--<script>--}}
    {{--$(function () {--}}
    {{--$('#items-table').DataTable()--}}
    {{--$('#example2').DataTable({--}}
    {{--'paging'      : true,--}}
    {{--'lengthChange': false,--}}
    {{--'searching'   : false,--}}
    {{--'ordering'    : true,--}}
    {{--'info'        : true,--}}
    {{--'autoWidth'   : false--}}
    {{--})--}}
    {{--})--}}
    {{--</script>--}}

    <script>
        $(function () {

            //Date picker
            $('#tanggal').datepicker({
                autoclose: true,
                // dateFormat: 'yyyy-mm-dd'
            })

            //Colorpicker
            $('.my-colorpicker1').colorpicker()
            //color picker with addon
            $('.my-colorpicker2').colorpicker()

            //Timepicker
            $('.timepicker').timepicker({
                showInputs: false
            })
        })
    </script>

    <script type="text/javascript">
         var table = $('#staffing-table').DataTable({
            processing: true,
            serverSide: true,
            ajax:  "{{ url('apiInvoice1') }}",
            columns: [
                {data: 'invoice_number', name: 'invoice_number'},
                {data: 'name', name: 'name'},
                {data: 'date_in', name: 'date_in'},
                {data: 'sub_total', name: 'sub_total'},
                {data: 'vat', name: 'vat'},
                {data: 'discount', name: 'discount'}, 
                {data: 'net_total', name: 'net_total'},
                {data: 'amount_paid', name: 'amount_paid'},
                {data: 'amount_due', name: 'amount_due'},
                {data: 'payment_status', name: 'payment_status'},
                {data: 'invoice_status', name: 'invoice_status'},
                {data: 'start_date', name: 'start_date'}, 
                {data: 'due_date', name: 'due_date'},  
                {data: 'action', name: 'action', orderable: false, searchable: false}
               
            ]
        });
     $(document).on('click','#add_btn',function(){
          save_method = "add";
          $('input[name=_method]').val('POST');
          $('#modal-form').modal('show');
          $('#modal-form form')[0].reset();
          $('.modal-title').text('New Invoice');
          $('#expensive').html('');
          add_expensive_row();
          calculate(0,0);
  
        });
$("#expensive").delegate("#qty","keyup",function(){
    var tr = $(this).parent().parent();
    var qty = $('#qty').val();
    var price=$('#price').val();

   // tr.find("#amt").html(qty.val() * tr.find(".price").val());
    tr.find(".amt").html( tr.find("#qty").val() * tr.find("#price").val() );
				calculate(0,0);
     
})
$("#expensive").delegate("#price","keyup",function(){
    var tr = $(this).parent().parent();

   // tr.find("#amt").html(qty.val() * tr.find(".price").val());
    tr.find(".amt").html( tr.find("#qty").val() * tr.find("#price").val() );
				calculate(0,0);
     
})
function calculate(dis,paid){
    var sub_total = 0;
    var gst = 0;
    var net_total = 0;
    var discount = dis;
    var paid_amt = paid;
    var due = 0;
    $(".amt").each(function(){
        sub_total = sub_total + ($(this).html() * 1);
      
    })
    gst = 0.18 * sub_total;
    net_total = gst + sub_total;
    net_total = net_total - discount;
    due = net_total - paid_amt;
    $("#gst").val(gst);
    $("#sub_total").val(sub_total);
    
    $("#discount").val(discount);
    $("#net_total").val(net_total);
    //$("#paid")
    $("#amount_due").val(due);

}

$("#discount").keyup(function(){
    var discount = $(this).val();
    
    calculate(discount,0);
})

$("#amount_paid").keyup(function(){
    var paid = $(this).val();
    var discount = $("#discount").val();
  
    calculate(discount,paid);
})


/*Order Accepting*/
 function add_expensive_row(count_charge = ''){
   var tr = $(this).parent().parent();
     var html = '';
      html += '<span id="row'+count_charge +'"><div class="row">';
    //   html += '<div class="col-md-3">';
    //   html += '<input type="text" name="title[]" id="title'+count_charge+'" class="form-control selectpicker" data-live-search="true" required  placeholder="title"></textarea>';
    //   html += '</div>';
      html += '<div class="col-md-6">';
      html += '<textarea name="description[]" id="description'+count_charge+'" class="form-control"   placeholder="Particulars" required ></textarea>';
      html += '<span class="help-block with-errors"></span>';
      html += '</div>';
      html += '<div class="col-md-2">';
      html += '<input type="text" name="qty[]"  id="qty" class="form-control" required placeholder="qty" value="1"/>';

      html += '</div>';
      html += '<div class="col-md-2">';
      html += '<input type="text" name="price[]"  id="price" class="form-control" required placeholder="cost" value="0"/>';
      html += '</div>';
      html += '<div class="col-md-1">';

      html += 'Tsh.<span class="amt" >0</span>';
      html += '</div>';
      html += '<div class="col-md-1">';
      if(count_charge == '')
      {
        html += '<button type="button" name="more_charge" id="more_charge" class="btn btn-success btn-xs">+</button>';
      }
      else
      {
        html += '<button type="button" name="remove" id="'+count_charge +'" class="btn btn-danger btn-xs remove">-</button>';
      }
      html += '</div>';
      html += '</div></div><br /></span>';
  
      $('#expensive').append(html);

      tr.find(".amt").html( tr.find("#qty").val() * tr.find("#price").val() );
				calculate(0,0);
        }
        var count_charge = 0;
    $(document).on('click', '#more_charge', function(){

     count_charge = count_charge+ 1;
    add_expensive_row(count_charge);
    var tr = $(this).parent().parent();
    tr.find(".amt").html( tr.find("#qty").val() * tr.find("#price").val() );
				calculate(0,0);
    calculate(0,0);
     });
     $(document).on('click', '.remove', function(){
        var tr = $(this).parent().parent();
        // tr.find(".amt").html( tr.find("#qty").val() * tr.find("#price").val() );
        // calculate(0,0);
    var row_no = $(this).attr("id");
     $('#row'+row_no).remove();
     tr.find(".amt").html( tr.find("#qty").val() * tr.find("#price").val() );
        calculate(0,0);
     });

  function editForm(id) {
            save_method = 'edit';
            $('input[name=_method]').val('PATCH');
            $('#modal-form form')[0].reset();
            $('#expensive').html('');
            count_charge=''; 
            $.ajax({
                url: "{{ url('invoice1') }}" + '/' + id + "/edit",
                type: "GET",
                dataType: "JSON",
                success: function(html) {
                    $('#modal-form').modal('show');
                    $('.modal-title').text('Edit Task Information');
                    $('#id').val(html.data[0].id);
                    $('#company_id').val(html.data[0].company_id); 
                    $('#date_in').val(html.data[0].date_in); 
                   $.each(html.data, function(i, item){
                   html_form=''; 
                   html_form+= '<span id="row'+count_charge +'"><div class="row">';
                   html_form+= '<div class="col-md-4">';
                   html_form += '<input type="text" name="description[]" id="description'+count_charge+'" value="'+html.data[i].description+'" class="form-control selectpicker" data-live-search="true" required  placeholder="name">';
                   html_form += '</div>';
                   html_form += '<div class="col-md-4">';
                   html_form+= '<input type="text" name="qty[]"  id="qty"  value="'+html.data[i].qty+'" class="form-control" required placeholder="cost"/>';
                   html_form += '</div>';
                   html_form += '<div class="col-md-1">';
                   html_form+= '<input type="text" name="price[]"  id="price"  value="'+html.data[i].cost+'" class="form-control" required placeholder="cost"/>';
                   html_form += '</div>';
                   html_form += '<div class="col-md-1">';
                   html_form+= '<input type="text" name="amt[]"  id="amt"  value="'+html.data[i].ucost+'" class="form-control" required placeholder="unity cost" style="cursor:pointer;"/>';
                   html_form += '</div>';
                   html_form+= '<div  class="col-md-2">';
               if(count_charge == '')
                {
                html_form += '<button type="button" name="more_charge" id="more_charge" class="btn btn-success btn-xs">+</button>';
                }
               else
               {
                html_form += '<button type="button" name="remove" id="'+count_charge +'" class="btn btn-danger btn-xs remove">-</button>';
               }
               html_form += '</div>';
               html_form+= '</div></div><br /></span>';
               $.isNumeric(count_charge)
               count_charge=0;
               count_charge=count_charge+1;
             $('#expensive').append(html_form);
                    });
             
                },
                error : function() {
                    alert("Nothing Data");
                }
            });
        }
             
         $(document).on('click','.pay',function(){
          var id=$(this).attr("id");
          var payment_status=$(this).attr("payment_status");
        
          $('#staffing_id').val(id);
          save_method = "add";
          $('#modal_payment').modal('show');
          var id=$(this).attr("id");
          $('input[name=_method]').val('POST');
          $('.modal-title').text('Payment Information');
         
          });
     


         $(document).on('click','.view',function(){
            $('#expensive').html('');
             var id=$(this).attr("id");
            $.ajax({
                url:"view_details/"+id,
                cache:false,
                success: function(html) {
                    $('#modal-form').modal('show');
                    $('.modal-title').text('Details');
                    $('#id').val(html.data[0].id);
                    $('#company_id').val(html.data[0].company_id); 
                    $('#date_in').val(html.data[0].date_in);
                    $.each(html.data, function(i, item){
                   html_form=''; 
                   html_form+= '<span id="row'+count_charge +'"><div class="row">';
                   html_form+= '<div class="col-md-5">';
                   html_form += '<label>Description</label>';
                   html_form += '<input type="text"   value="'+html.data[i].description+'" class="form-control" readonly/>';
                   html_form += '</div>';
                   html_form += '<div class="col-md-1">';
                   html_form += '<label>Qty</label>';
                   html_form+= '<input type="text"   value="'+html.data[i].qty+'" class="form-control" readonly/>';
                   html_form += '</div>';
                   html_form += '<div class="col-md-3">';
                   html_form += '<label>Cost</label>';
                   html_form+= '<input type="text"   value="'+html.data[i].cost+'" class="form-control" readonly/>';
                   html_form += '</div>';
                   html_form += '<div class="col-md-3">';
                   html_form += '<label>Unity Cost</label>'
                   html_form+= '<input type="text"   value="'+html.data[i].ucost+'" class="form-control" readonly/>';
                   html_form += '</div>';
                   html_form+= '</div></div><br /></span>';
            
                  $('#expensive').append(html_form);
                  
                      });
             
                },
                error : function() {
                    alert("Nothing Data");
                }
            });

         })
        function deleteData(id){
            var csrf_token = $('meta[name="csrf-token"]').attr('content');
            swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                cancelButtonColor: '#d33',
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then(function () {
                $.ajax({
                    url : "{{ url('invoice1') }}" + '/' + id,
                    type : "POST",
                    data : {'_method' : 'DELETE', '_token' : csrf_token},
                    success : function(data) {
                        table.ajax.reload();
                        swal({
                            title: 'Success!',
                            text: data.message,
                            type: 'success',
                            timer: '1500'
                        })
                    },
                    error : function () {
                        swal({
                            title: 'Oops...',
                            text: data.message,
                            type: 'error',
                            timer: '1500'
                        })
                    }
                });
            });
        }
     

        $(function(){
            $('#modal-form form').validator().on('submit', function (e) {
                var description= $('#description').val();
            
                if (!e.isDefaultPrevented()){
                    var id = $('#id').val();
                    if (save_method == 'add') url = "{{ url('invoice1') }}";
                    else url = "{{ url('invoice1') . '/' }}" + id;

                    $.ajax({
                        url : url,
                        type : "POST",
                        //hanya untuk input data tanpa dokumen
//                      data : $('#modal-form form').serialize(),
                        data: new FormData($("#modal-form form")[0]),
                        contentType: false,
                        processData: false,
                        success : function(data) {
                            $('#modal-form').modal('hide');
                            table.ajax.reload();
                            swal({
                                title: 'Success!',
                                text: data.message,
                                type: 'success',
                                timer: '1500'
                            })
                        },
                        error : function(data){
                            swal({
                                title: 'Oops...',
                                text: data.message,
                                type: 'error',
                                timer: '1500'
                            })
                        }
                    });
                    return false;
                }
            });

        });

        $(function(){
            $('#form-item-payment').validator().on('submit', function (e) {
                if (!e.isDefaultPrevented()){
                 
                    if (save_method == 'add') url = "{{ url('payment') }}";
           

                    $.ajax({
                        url : url,
                        type : "POST",
                        //hanya untuk input data tanpa dokumen
//                      data : $('#modal-form form').serialize(),
                        data: new FormData($("#form-item-payment")[0]),
                        contentType: false,
                        processData: false,
                        success : function(data) {
                            $('#modal_payment').modal('hide');
                            table.ajax.reload();
                            swal({
                                title: 'Success!',
                                text: data.message,
                                type: 'success',
                                timer: '1500'
                            })
                        },
                        error : function(data){
                            swal({
                                title: 'Oops...',
                                text: data.message,
                                type: 'error',
                                timer: '1500'
                            })
                        }
                    });
                    return false;
                }
            });

        });
    </script>

@endsection
