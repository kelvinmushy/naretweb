<div class="modal fade" id="modal-form" tabindex="1" role="dialog" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form  id="form-item" method="post" class="form-horizontal" data-toggle="validator" enctype="multipart/form-data" >
                {{ csrf_field() }} {{ method_field('POST') }}
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title"></h3>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="id" name="id">
                    <div class="box-body">
                    <div class="row">
                      <div class='col-md-6'>
                      <label>Customer Name:</label>
                        <input type="text" name="customer_name" id="customer_name" class="form-control" required>
                        <span class="help-block with-errors"></span>
                      </div>
                      <div class='col-md-6'>
                       <label>Phone Number:</label>
                       <input type="text" name="phone_number" id="phone_number" class="form-control" required>
                       <span class="help-block with-errors"></span>
                      </div>
                      </div>
                      <div class="row">
                      <div class='col-md-6'>
                       <label>Email:</label>
                       <input type="email" name="email" id="email" class="form-control" required>
                       <span class="help-block with-errors"></span>
                        </select>
                      </div>
                       <div class='col-md-6'>
                       <label>Tin number:</label>
                       <input type="text" name="tin_number" id="tin_number" class="form-control">
                      </div>
                      </div>
                      <div class="row">
                      <div class='col-md-6'>
                       <label>Location:</label>
                       <input type="text" name="location" id="location" class="form-control" required>
                       <span class="help-block with-errors"></span>
                      </div>
                      <div class='col-md-6'>
                      <label>Date</label>
                      <input type="hidden" id="staff_type" name="staff_type" value="fumigation" >
                      <input type="text" class="form-control" id="date_in" name="date_in" value="<?php $kevi=date('Y-m-d');echo $kevi?>"   required readonly>
                      <span class="help-block with-errors"></span>
                      </div>
                      </div>
                      <hr>
                      </hr>
                      <div class="row">
                      <div class='col-md-12'>
                      <span id="expensive"></span>
                       </span>
                      </div>
                       </div>
                       <hr></hr>
                       <div class="row">
                       <label for="sub_total" class="col-sm-3 col-form-label" align="right">Sub Total</label>
                      <div class="col-sm-6">
                        <input type="text" readonly name="sub_total" class="form-control form-control-sm" id="sub_total" required/>
                      </div>
                    </div>
                    <div class="form-group row">
                
                      <label for="gst" class="col-sm-3 col-form-label" align="right">VAT (18%)</label>
                      <div class="col-sm-6">
                        <input type="text" readonly name="vat" class="form-control form-control-sm" id="gst" required/>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="discount" class="col-sm-3 col-form-label" align="right">Discount</label>
                      <div class="col-sm-6">
                        <input type="text" name="discount" class="form-control form-control-sm" id="discount" required/>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="net_total" class="col-sm-3 col-form-label" align="right">Net Total</label>
                      <div class="col-sm-6">
                        <input type="text" readonly name="net_total" class="form-control form-control-sm" id="net_total" required/>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="due" class="col-sm-3 col-form-label" align="right">Due</label>
                      <div class="col-sm-6">
                        <input type="text" readonly name="amount_due" class="form-control form-control-sm" id="amount_due" required/>
                      </div>
                    </div>
                       </div>
                    <!-- /.box-body -->

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">SaveandPrint</button>
                </div>

            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->


    


    


