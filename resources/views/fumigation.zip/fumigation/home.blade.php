@extends('layouts.casual_labour.master')

@section('top')
@endsection

@section('content')
<!-- Small boxes (Stat box) -->
<div class="row">
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-aqua">
            <div class="inner">
                <h3>Users</h3>

                <h3><strong>{{$sum_customer}}</strong></h3>
            </div>
            <div class="icon">
                <i class="ion ion-person"></i>
            </div>
        
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-green">
            <div class="inner">
            <p><strong>Customer(s)</strong></p>
                <h3><strong>{{$sum_customer}}</strong></h3>
            </div>
            <div class="icon">
                <i class="fa fa-list"></i>
            </div>
         
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-yellow">
            <div class="inner">
            <p><strong>Open Invoice(s)</strong></p>
                <h3>{{$invoice_open_count}}=:Tsh<strong>{{$invoice_open_sum}}</strong></h3>
            </div>
            <div class="icon">
                <i class="fa fa-cubes"></i>
            </div>
           
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-red">
            <div class="inner">
            <p><strong>Closed Invoice(s)</strong></p>
                <h3>{{$close_invoice_count}}=Tsh:<strong>{{$close_invoice_sum}}</strong></h3>
            </div>
            <div class="icon">
                <i class="fa fa-users"></i>
            </div>
        </div>
    </div>
    <!-- ./col -->
</div>



<div class="row">
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-navy">
            <div class="inner">
                <p><strong>Paid Invoice(s)</strong></p>

                <h3>Tsh:<strong>{{$invoice_paid}}</strong></h3>
            </div>
            <div class="icon">
                <i class="ion ion-bag"></i>
            </div>
        
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-teal">
            <div class="inner">
            <p><strong>Invoice Due to Pay</strong></p>
                <h3>{{$invoice_due_count}}=Tsh:<strong>{{$invoice_due}}</strong></h3>
            </div>
            <div class="icon">
                <i class="ion ion-stats-bars"></i>
            </div>
         
        </div>
    </div>
 
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-gray">
            <div class="inner">
            <p><strong>Today sales Invoice(s)</strong></p>
            <h3><strong>{{$invoice_dayopen_count}}</strong>-Tsh:{{$invoice_dayopen_sum}}</h3>
            </div>
            <div class="icon">
                <i class="fa fa-minus"></i>
            </div>
          
        </div>
    </div>
    <!-- ./col -->
       <!-- ./col -->
       <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-maroon">
            <div class="inner">
            <p><strong>Labour Cost</strong></p>
                <h3>Tsh:<strong>{{$labour_pay}}</strong></h3>
             
            </div>
            <div class="icon">
                <i class="fa fa-plus"></i>
            </div>
        </div>
    </div>
    <!-- ./col -->
    <div id="container" class=" col-xs-6"></div>
</div>

<div class="row">
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-navy">
            <div class="inner">
                <p><strong>Pending Invoice(s)</strong></p>

                <h3>{{$invoice_pending_count}}Tsh:<strong>{{$invoice_pending_sum}}</strong></h3>
            </div>
            <div class="icon">
                <i class="ion ion-bag"></i>
            </div>
        
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-teal">
            <div class="inner">
            <p><strong>Invoice(s) Waiting</strong></p>
                <h3>{{$invoice_wait_count}}=Tsh:<strong>{{$invoice_wait_sum}}</strong></h3>
            </div>
            <div class="icon">
                <i class="ion ion-stats-bars"></i>
            </div>
         
        </div>
    </div>
 
    <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-gray">
            <div class="inner">
            <p><strong>Today Cloesed Invoice(s)</strong></p>
            <h3><strong>{{$invoice_dayclose_count}}</strong>-Tsh:{{$invoice_dayclose_sum}}</h3>
            </div>
            <div class="icon">
                <i class="fa fa-minus"></i>
            </div>
          
        </div>
    </div>
    <!-- ./col -->
       <!-- ./col -->
       <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-maroon">
            <div class="inner">
            <p><strong>Total Invoice(s)</strong></p>
                <h3>{{$invoice_count}}-Tsh:<strong>{{$invoice_sum}}</strong></h3>
             
            </div>
            <div class="icon">
                <i class="fa fa-plus"></i>
            </div>
        </div>
    </div>
    <!-- ./col -->
    <div id="container" class=" col-xs-6"></div>
</div>
@endsection

@section('top')
@endsection
